import React from 'react'
import "./Download.css"
const Download = () => {
    return (
        <div>Download</div>
    )
}

export default Download