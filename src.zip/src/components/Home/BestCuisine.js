import React from 'react'
import "./BestCuisine.css"
const BestCuisine = () => {
    return (
        <div>

        </div>
    )
}

export default BestCuisine