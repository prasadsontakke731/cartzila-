import React from 'react'
import "./FoodType.css"
const FoodType = () => {
    return (
        <div>FoodType</div>
    )
}

export default FoodType