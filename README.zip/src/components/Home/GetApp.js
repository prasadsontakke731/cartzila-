import React from 'react'
import "./GetApp.css"
const GetApp = () => {
    return (
        <div>GetApp</div>
    )
}

export default GetApp