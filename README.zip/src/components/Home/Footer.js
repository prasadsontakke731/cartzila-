import React from 'react'
import "./Footer.cssss"
const Footer = () => {
    return (
        <div>Footer</div>
    )
}

export default Footer