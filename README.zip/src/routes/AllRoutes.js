import React from 'react'

const AllRoutes = () => {
    return (
        <div>AllRoutes</div>
    )
}

export default AllRoutes 